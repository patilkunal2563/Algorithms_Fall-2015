import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class DFSImplement {

	/**
	 * @param args
	 */
	public static ArrayList<BSTclass> bstClassList = new ArrayList<BSTclass>();
	public static ArrayList<Integer> finalPath = new ArrayList<Integer>();
	public static ArrayList<Integer> path = new ArrayList<Integer>();
	//public static ArrayList<Integer> currentSolutionTracker = new ArrayList<Integer>();
	public static ArrayList<Integer> tempClauseValues = new ArrayList<Integer>();
	public static ArrayList<Integer> tempClauseValues1 = new ArrayList<Integer>();
	public static ArrayList<Integer> clauseValues = new ArrayList<Integer>();
	public static int counter = 1;
	public static int solutionCounter = 0;
	public static Map<Integer, ArrayList<Integer>> solutionMap = new HashMap<Integer, ArrayList<Integer>>();
	public static String finalOutput = "";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String inputFile = args[0];
		String outputFile = args[1];
		readInputFile(inputFile,outputFile);
		System.out.println("Output File Successfully Genereted");
	}

	private static void readInputFile(String inputFile2, String outputFile) {
		// TODO Auto-generated method stub
		
		
			try {

				File inputFile = new File(inputFile2);
				Map<Integer, Integer> valueMap = new HashMap<Integer, Integer>();
				List<Integer> clauseValuesArray = new ArrayList<Integer>();
				int counter1 = 0;
				Scanner fileReader = new Scanner(inputFile);
				String[] arr = fileReader.nextLine().split(" ");
			BSTclass bst = new BSTclass(Integer.parseInt(arr[0]),
						Integer.parseInt(arr[1]), Integer.parseInt(arr[2]));
				while (fileReader.hasNext()) {

					clauseValuesArray.add(fileReader.nextInt());

				}
				for (int k = 0; k < clauseValuesArray.size(); k++) {
					// System.out.println(counter1+"---->"+clauseValuesArray.get(k));
					valueMap.put(counter1, clauseValuesArray.get(k));
					counter1++;
				}

				bst.setClauseValues(valueMap);
				bst.setFileName(inputFile.getName());
				bstClassList.add(bst);
		//		System.out.println(bstClassList.get(0).getNoOfVariables());
				for(int k=0;k<bstClassList.get(0).getNoOfVariables();k++)
				{
					finalPath.add(-1);
				}
					int depth = 0;
				// System.out.println("path is -->"+path);
					Map<Integer, Integer> valueMap1 = bstClassList.get(0).getClauseValues();
					
					for (int k = 0; k < valueMap1.size(); k++) {
						clauseValues.add(valueMap1.get(k));
						tempClauseValues.add(valueMap1.get(k));
						// System.out.println(clauseValues[k]);
					}
			//		System.out.println(tempClauseValues);
					long startTime = System.currentTimeMillis();
					backTrackComputeH1(depth);
				long endTime = System.currentTimeMillis();
				long totalTime = endTime - startTime;

				//String outputFileName = bst.getFileName().substring(5);
				try {
					FileWriter writer = new FileWriter(new File(outputFile));
					finalOutput = getSolution(finalPath);
					if (finalOutput != "") {
			//			System.out.println(finalOutput);
						writer.write(finalOutput);
						// System.out.println("Solution is - \n");
					} else {
						writer.write("No satisfying assignment\n");
				//		System.out.println("NO Satisfying assignment\n");
					}

					writer.write("Run time is " + totalTime + " milliseconds.");
					//System.out.println("Run time is " + totalTime						+ " milliseconds.");
					// solutionMap.clear();
					writer.close();
					finalOutput = "";
					finalPath.clear();
					path.clear();
					bstClassList.clear();
					fileReader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		

	}

	private static String getSolution(ArrayList<Integer> finalPath2) {
		// TODO Auto-generated method stub
		finalOutput = "";
	/*	for(int i=0;i<finalPath2.size();i++)
		{
			System.out.println(finalPath2.get(i));
		}*/
		int counter1 = 0;
		for(int i=0;i<finalPath2.size();i++)
		{
			if(finalPath2.get(i)!= -1)
			{
				counter1 = counter1 + 1;
			}
		}
		if(counter1>0)
		{
			for(int i=0;i<finalPath2.size();i++)
			{
				if(finalPath2.get(i)== -1)
				{
					finalPath2.set(i, 0);
				}
			}
		
	//	System.out.println(finalPath2);
		finalOutput = finalOutput + "The Solution is\n";
		for (int i = 0; i < finalPath2.size(); i++) {

			finalOutput = finalOutput + "x[" + (i+1) + "]="
					+ finalPath2.get(i) + "\n";
		}
		}
		else
		{
			finalOutput = finalOutput + "There is no satisfying assignment\n";
		}
		return finalOutput;
	}

	private static void backTrackComputeH1(int depth) {
 
		
		if(!tempClauseValues.isEmpty())
		{
		if(depth <=bstClassList.get(0).getNoOfVariables())
		{
			
			int flag = checkPureLiteralCondition(depth+1);
	//		System.out.println("flag"+flag);
			if(flag == 1)
			{
		//		System.out.println("here 1");
				finalPath.set(depth, 1);
		//		System.out.println(finalPath);
				checkClauses(depth+1);
		//		System.out.println("hi");
				
				for(int i=0;i<depth;i++)
				{
					int flag1 = checkPureLiteralCondition(i+1);
			//		System.out.println(flag1);
					if(flag1 == 1)
					{
						finalPath.set(i, 1);
						
						checkClauses(i+1);
					}
					if(flag1==0)
					{
						finalPath.set(i, 0);
						
						checkClauses(i+1);
					}
				}
			
				path.add(1);

				backTrackComputeH1(depth+1);
				path.remove(path.size() - 1);
			}
			 if(flag==0)
			{
			//	System.out.println("here 0");
				finalPath.set(depth, 0);
				
				for(int i=0;i<depth;i++)
				{
					int flag1 = checkPureLiteralCondition(i+1);
					if(flag1 == 1)
					{
						finalPath.set(i, 1);
						
						checkClauses(i+1);
					}
					if(flag1==0)
					{
						finalPath.set(i, 0);
						
						checkClauses(i+1);
					}
				}
			
				path.add(0);
				backTrackComputeH1(depth+1);
				path.remove(path.size() - 1);
			}
			if(flag==2)
			{
		//		System.out.println("here -2");
				path.add(1);

				backTrackComputeH1(depth+1);
				path.remove(path.size() - 1);
				path.add(0);
				backTrackComputeH1(depth+1);
				path.remove(path.size() - 1);
			}
		
		}
		
		}
		
		}

	private static void checkClauses(int i) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> clauseValues1 = tempClauseValues;
	//	System.out.println(clauseValues1);
			// System.out.println(clauseValues[k]);
		ArrayList<Integer> tempArrayclause = new ArrayList<Integer>();
		//System.out.println(bstClassList.get(0).getNoOfVariables());
		//System.out.println("vbl::"+bstClassList.get(0).variablsPerClause);
		for(int count=0;count<clauseValues1.size();count++)
		{
			for (int innerCount = count; innerCount < ((bstClassList.get(0).variablsPerClause)+count); innerCount++) {
				if(i == Math.abs(clauseValues1.get(innerCount)))
				{
					for (int finalCount = count; finalCount < (bstClassList.get(0).variablsPerClause+count); finalCount++) {
						clauseValues1.set(finalCount, 0);
					}
				}
			}
			count = count + (bstClassList.get(0).variablsPerClause - 1);
		}
		//System.out.println(clauseValues1);
		
		
		for(int count1 = 0; count1 < clauseValues1.size();count1++)
		{
			if(clauseValues1.get(count1)!=0)
			{
				tempArrayclause.add(clauseValues1.get(count1));
			}
		}
		tempClauseValues=tempArrayclause;
	//	System.out.println(tempClauseValues);
	}

	private static int checkPureLiteralCondition(int depth) {
		// TODO Auto-generated method stub
		int varCount=0;
		int negatedVariables=0;
		int nonNegatedVariables=0;
		ArrayList<Integer> tempClauseValue = tempClauseValues;
		//System.out.println("hi");
		//System.out.println(clauseList);
		int[] clauseValueArray = new int[tempClauseValue.size()];
		for(int k=0;k<tempClauseValue.size();k++){
			clauseValueArray[k]=tempClauseValue.get(k);
		}

        
       // System.out.println("variable::"+variable);
		for(int j=0;j<clauseValueArray.length;j++){
			if((depth)==Math.abs(clauseValueArray[j])){
				varCount=varCount+1;
				int decision=depth*(-1);
				if(clauseValueArray[j]==(depth)){
					nonNegatedVariables=nonNegatedVariables+1;
				}
				if(clauseValueArray[j]==(decision)){
					negatedVariables=negatedVariables+1;
				}
				
				
			}
		}
		
		if((varCount==negatedVariables)&&(varCount!=0)){
			
			return 0;
		}
        if((varCount==nonNegatedVariables)&&(varCount!=0)){
			return 1;
		}
		return 2;

		
	}


}
