import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class BSTclass {

	int noOfVariables;
	int noOfClauses;
	int variablsPerClause;
	String fileName;
	Map<Integer, Integer> clauseValues;
	
	public Map<Integer, Integer> getClauseValues() {
		return clauseValues;
	}
	public void setClauseValues(Map<Integer, Integer> valueMap) {
		this.clauseValues = valueMap;
	}
	public BSTclass(int noOfVariables, int noOfClauses, int variablsPerClause) {
		super();
		this.noOfVariables = noOfVariables;
		this.noOfClauses = noOfClauses;
		this.variablsPerClause = variablsPerClause;
	}
	public int getNoOfVariables() {
		return noOfVariables;
	}
	public void setNoOfVariables(int noOfVariables) {
		this.noOfVariables = noOfVariables;
	}
	public int getNoOfClauses() {
		return noOfClauses;
	}
	public void setNoOfClauses(int noOfClauses) {
		this.noOfClauses = noOfClauses;
	}
	public int getVariablsPerClause() {
		return variablsPerClause;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public void setVariablsPerClause(int variablsPerClause) {
		this.variablsPerClause = variablsPerClause;
	}
	public void setInputFileName(String name) {
		// TODO Auto-generated method stub
		this.fileName = name;
	}
	
	
}
