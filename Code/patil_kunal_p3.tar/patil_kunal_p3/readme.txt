Java
Run Program with ./Submission <input.txt> <output.txt> command in project directory.
Input files are stored in folder named as "inputFolder". 
Output files are generated in source folder only.
